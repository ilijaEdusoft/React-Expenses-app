import BasicForm from "./components/BasicForm";
import SimpleInput from "./components/SimpleInput";

function App() {
  return (
    <div>
      <div className="app">
        <BasicForm />
      </div>
      <div className="app">
        <SimpleInput />
      </div>
    </div>
  );
}

export default App;
