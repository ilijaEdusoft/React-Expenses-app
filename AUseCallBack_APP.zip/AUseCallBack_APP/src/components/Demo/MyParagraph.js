import React from "react";

const MyParagraph = (props) => {
  console.log("MyPARAGRAPH_RUNNING");

  return <p>{props.children}</p>;
};
export default MyParagraph;
